

#include<stm32f4xx.h>

void EXTI15_10_IRQHandler(void)
{
	GPIOA->ODR ^= 0X20;                 //ISR funtionality
	for(int i=0;i<3000000;i++);         //Delay
	EXTI->PR |= 0X2000;                 //Return back from ISR to main program
}

int main()
{
	__disable_irq();                     //Disable the IRQ
	RCC->AHB1ENR |= 0x5;                 // Enable clock for PA & PC
	GPIOA->MODER |= 0x400;               //Set out put for PA
	RCC->APB2ENR |= 0x4000;              //
	SYSCFG->EXTICR[3] |= 0x20;           //Enable SYSCFG for trigger the interrupt
	EXTI->IMR |= 0X2000;                 //Make mask pin set to 1 of corresponding IRQ-Pin
	EXTI->FTSR |= 0X2000;                //Trigger the interrupt on falling edge
	NVIC_EnableIRQ(EXTI15_10_IRQn);      //Generate IRQ
	__enable_irq();                      //Enable the request line
	while(1);
}
