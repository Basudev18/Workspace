/*
 * usart.h
 *
 *  Created on: Apr 25, 2023
 *      Author: prita
 */

#ifndef USART_H_
#define USART_H_



void delay(int);
int __io_putchar(unsigned char);
void USART2_init(void);
void  USART2_transmit(unsigned char );

#endif /* USART_H_ */
