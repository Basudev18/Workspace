/*
 Application:

 GPIO's

 step1:
 step2:
 step3:

 Author:

*/





#include "main.h"


void delay(int T)
{
	int i;
	while(T--)
	{
	for(i=0;i<4000;i++);
	}
}

int main()
{
	RCC->AHB1ENR |=0x1;
	RCC->AHB1ENR |=1<<1;
	RCC->AHB1ENR |=1<<2;

	GPIOA->MODER |= 0x400;
	GPIOA->MODER |= 0x1000;
	GPIOC->MODER |= 0x4000;
	GPIOB->MODER |= 0x10000;
	while(1)
	{
		GPIOA->ODR |= 0x20;
		delay(100);
		GPIOA->ODR &= ~(0x20);
		delay(100);

		GPIOA->ODR |= 0x40;
	    delay(100);
	    GPIOA->ODR &= ~(0x40);
	    delay(100);

	    GPIOC->ODR |= 0x80;
	    delay(100);
	    GPIOC->ODR &= ~(0x80);
	    delay(100);

	    GPIOB->ODR |= 0x100;
	    delay(100);
	    GPIOB->ODR &= ~(0x100);
	    delay(100);
	}
}
