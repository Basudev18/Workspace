/*
 Application:

 GPIO's

 step1:
 step2:
 step3:

 Author:

*/





#include "main.h"


void delay(int T)
{
	int i;
	while(T--)
	{
	for(i=0;i<4000;i++);
	}
}

int main()
{
	RCC->AHB1ENR |=0x1;
	GPIOA->MODER |= 0x100;
	while(1)
	{
		GPIOA->BSRR |= 0x20;
		//HAL_GPIO_TogglePin(GPIOA,GPIO_PIN5);
		delay(1000);
		GPIOA->BSRR |= 0x20;
		delay(1000);
	}
}
