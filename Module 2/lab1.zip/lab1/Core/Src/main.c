/*
 Application:Blink LED-on-Buttom Press
 LED-PA5
 Switch-PC13

 GPIO's

 step1:
 step2:
 step3:

 Author:

*/





#include "main.h"


void delay(int T)
{
	int i;
	while(T--)
	{
	for(i=0;i<4000;i++);
	}
}

int main()
{
    RCC->AHB1ENR |= 0x1;
	RCC->AHB1ENR |= 1<<2;
	GPIOA->MODER |= 0x400;
	GPIOC->MODER |= 0x00;
	while(1)
	{


		if(!(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_13)))
		{
		GPIOA->BSRR |= 0x20;

		}
		else
		{
		GPIOA->BSRR |= 0x200000;

		}
	}
}
